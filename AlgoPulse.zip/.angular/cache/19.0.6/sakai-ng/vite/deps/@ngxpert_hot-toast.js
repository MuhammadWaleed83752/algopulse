import {
  CommonModule,
  NgClass,
  NgStyle,
  isPlatformServer
} from "./chunk-4THGAS2G.js";
import {
  ApplicationRef,
  ChangeDetectionStrategy,
  ChangeDetectorRef,
  Component,
  Directive,
  EnvironmentInjector,
  EventEmitter,
  Injectable,
  InjectionToken,
  Injector,
  Input,
  NgZone,
  Output,
  PLATFORM_ID,
  Renderer2,
  TemplateRef,
  ViewChild,
  ViewChildren,
  ViewContainerRef,
  createComponent,
  effect,
  inject,
  input,
  makeEnvironmentProviders,
  setClassMetadata,
  signal,
  ɵɵNgOnChangesFeature,
  ɵɵadvance,
  ɵɵattribute,
  ɵɵclassProp,
  ɵɵconditional,
  ɵɵdefineComponent,
  ɵɵdefineDirective,
  ɵɵdefineInjectable,
  ɵɵelement,
  ɵɵelementContainer,
  ɵɵelementEnd,
  ɵɵelementStart,
  ɵɵgetCurrentView,
  ɵɵlistener,
  ɵɵloadQuery,
  ɵɵnextContext,
  ɵɵproperty,
  ɵɵpureFunction2,
  ɵɵqueryRefresh,
  ɵɵrepeater,
  ɵɵrepeaterCreate,
  ɵɵresetView,
  ɵɵrestoreView,
  ɵɵsanitizeHtml,
  ɵɵstyleProp,
  ɵɵtemplate,
  ɵɵtext,
  ɵɵtextInterpolate,
  ɵɵviewQuery
} from "./chunk-FCPBNRVL.js";
import {
  defer
} from "./chunk-4N4GOYJH.js";
import "./chunk-5OPE3T2R.js";
import {
  BehaviorSubject,
  Subject,
  filter,
  map,
  race,
  tap
} from "./chunk-FHTVLBLO.js";
import {
  __async,
  __objRest,
  __spreadProps,
  __spreadValues
} from "./chunk-3OV72XIM.js";

// node_modules/@ngneat/overview/fesm2022/ngneat-overview.mjs
var TeleportService = class _TeleportService {
  constructor() {
    this.outlets = new BehaviorSubject("");
    this.ports = /* @__PURE__ */ new Map();
  }
  outlet$(name) {
    return this.outlets.pipe(filter((current) => current === name), map((name2) => this.ports.get(name2)));
  }
  newOutlet(name) {
    this.outlets.next(name);
  }
  static {
    this.ɵfac = function TeleportService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _TeleportService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _TeleportService,
      factory: _TeleportService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TeleportService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var TeleportDirective = class _TeleportDirective {
  constructor() {
    this.teleportTo = input();
    this.subscription = null;
    this.tpl = inject(TemplateRef);
    this.service = inject(TeleportService);
  }
  ngOnChanges(changes) {
    if (changes.teleportTo && typeof this.teleportTo() === "string") {
      this.dispose();
      this.subscription = this.service.outlet$(this.teleportTo()).subscribe((outlet) => {
        if (outlet) {
          this.viewRef = outlet.createEmbeddedView(this.tpl);
        }
      });
    }
  }
  ngOnDestroy() {
    this.dispose();
  }
  dispose() {
    this.subscription?.unsubscribe();
    this.subscription = null;
    this.viewRef?.destroy();
  }
  static {
    this.ɵfac = function TeleportDirective_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _TeleportDirective)();
    };
  }
  static {
    this.ɵdir = ɵɵdefineDirective({
      type: _TeleportDirective,
      selectors: [["", "teleportTo", ""]],
      inputs: {
        teleportTo: [1, "teleportTo"]
      },
      features: [ɵɵNgOnChangesFeature]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TeleportDirective, [{
    type: Directive,
    args: [{
      selector: "[teleportTo]",
      standalone: true
    }]
  }], null, null);
})();
var TeleportOutletDirective = class _TeleportOutletDirective {
  constructor() {
    this.teleportOutlet = input();
    this.vcr = inject(ViewContainerRef);
    this.service = inject(TeleportService);
    effect(() => {
      const teleportOutlet = this.teleportOutlet();
      if (typeof teleportOutlet === "string") {
        this.service.ports.set(teleportOutlet, this.vcr);
        this.service.newOutlet(teleportOutlet);
      }
    });
  }
  ngOnDestroy() {
    this.service.ports.delete(this.teleportOutlet());
  }
  static {
    this.ɵfac = function TeleportOutletDirective_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _TeleportOutletDirective)();
    };
  }
  static {
    this.ɵdir = ɵɵdefineDirective({
      type: _TeleportOutletDirective,
      selectors: [["", "teleportOutlet", ""]],
      inputs: {
        teleportOutlet: [1, "teleportOutlet"]
      }
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(TeleportOutletDirective, [{
    type: Directive,
    args: [{
      selector: "[teleportOutlet]",
      standalone: true
    }]
  }], () => [], null);
})();
var CompRef = class {
  constructor(options) {
    this.options = options;
    if (options.vcr) {
      this.ref = options.vcr.createComponent(options.component, {
        index: options.vcr.length,
        injector: options.injector || options.vcr.injector
      });
    } else {
      this.ref = createComponent(options.component, {
        elementInjector: options.injector,
        environmentInjector: options.environmentInjector
      });
      options.appRef.attachView(this.ref.hostView);
    }
  }
  setInput(input2, value) {
    this.ref.setInput(input2, value);
    return this;
  }
  setInputs(inputs) {
    Object.keys(inputs).forEach((input2) => {
      this.ref.setInput(input2, inputs[input2]);
    });
    return this;
  }
  detectChanges() {
    this.ref.hostView.detectChanges();
    return this;
  }
  updateContext(context) {
    this.options.contextSignal?.set(context);
    return this;
  }
  appendTo(container) {
    container.appendChild(this.getElement());
    return this;
  }
  removeFrom(container) {
    container.removeChild(this.getElement());
    return this;
  }
  getRawContent() {
    return this.getElement().outerHTML;
  }
  getElement() {
    return this.ref.location.nativeElement;
  }
  destroy() {
    this.ref.destroy();
    !this.options.vcr && this.options.appRef.detachView(this.ref.hostView);
    this.ref = null;
  }
};
function isTemplateRef(value) {
  return value instanceof TemplateRef;
}
function isComponent(value) {
  return typeof value === "function";
}
function isString(value) {
  return typeof value === "string";
}
var TplRef = class {
  constructor(args) {
    this.args = args;
    if (this.args.vcr) {
      this.ref = this.args.vcr.createEmbeddedView(this.args.tpl, this.args.context || {}, {
        injector: args.injector
      });
      this.ref.detectChanges();
    } else {
      this.ref = this.args.tpl.createEmbeddedView(this.args.context || {}, args.injector);
      this.ref.detectChanges();
      this.args.appRef.attachView(this.ref);
    }
  }
  detectChanges() {
    this.ref.detectChanges();
    return this;
  }
  getElement() {
    const rootNodes = this.ref.rootNodes;
    if (rootNodes.length === 1 && rootNodes[0] === Node.ELEMENT_NODE) {
      this.element = rootNodes[0];
    } else {
      this.element = document.createElement("div");
      this.element.append(...rootNodes);
    }
    return this.element;
  }
  destroy() {
    if (this.ref.rootNodes[0] !== 1) {
      this.element?.parentNode.removeChild(this.element);
      this.element = null;
    }
    if (!this.args.vcr) {
      this.args.appRef.detachView(this.ref);
    }
    this.ref.destroy();
    this.ref = null;
  }
  updateContext(context) {
    Object.assign(this.ref.context, context);
    return this;
  }
};
var StringRef = class {
  constructor(value) {
    this.value = value;
  }
  getElement() {
    return this.value;
  }
  detectChanges() {
    return this;
  }
  updateContext() {
    return this;
  }
  destroy() {
  }
};
var VIEW_CONTEXT = new InjectionToken("Component context");
var ViewService = class _ViewService {
  constructor() {
    this.injector = inject(Injector);
    this.appRef = inject(ApplicationRef);
    this.environmentInjector = inject(EnvironmentInjector);
  }
  createComponent(component, options = {}) {
    let injector = options.injector ?? this.injector;
    let contextSignal;
    if (options.context) {
      contextSignal = signal(options.context);
      injector = Injector.create({
        providers: [{
          provide: VIEW_CONTEXT,
          useValue: contextSignal.asReadonly()
        }],
        parent: injector
      });
    }
    return new CompRef({
      component,
      vcr: options.vcr,
      injector,
      appRef: this.appRef,
      environmentInjector: options.environmentInjector || this.environmentInjector,
      contextSignal
    });
  }
  createTemplate(tpl, options = {}) {
    return new TplRef({
      vcr: options.vcr,
      appRef: this.appRef,
      tpl,
      context: options.context,
      injector: options.injector
    });
  }
  createView(content, viewOptions = {}) {
    if (isTemplateRef(content)) {
      return this.createTemplate(content, viewOptions);
    } else if (isComponent(content)) {
      return this.createComponent(content, viewOptions);
    } else if (isString(content)) {
      return new StringRef(content);
    } else {
      throw "Type of content is not supported";
    }
  }
  static {
    this.ɵfac = function ViewService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ViewService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _ViewService,
      factory: _ViewService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ViewService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], null, null);
})();
var DynamicViewComponent = class _DynamicViewComponent {
  constructor() {
    this.content = input();
  }
  static {
    this.ɵfac = function DynamicViewComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _DynamicViewComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _DynamicViewComponent,
      selectors: [["dynamic-view"]],
      inputs: {
        content: [1, "content"]
      },
      decls: 1,
      vars: 1,
      consts: [[3, "innerHTML"]],
      template: function DynamicViewComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
        }
        if (rf & 2) {
          ɵɵproperty("innerHTML", ctx.content(), ɵɵsanitizeHtml);
        }
      },
      encapsulation: 2
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DynamicViewComponent, [{
    type: Component,
    args: [{
      selector: "dynamic-view",
      standalone: true,
      template: ` <div [innerHTML]="content()"></div> `
    }]
  }], null, null);
})();
var DynamicViewDirective = class _DynamicViewDirective {
  constructor() {
    this.view = input(void 0, {
      alias: "dynamicView"
    });
    this.injector = input(void 0, {
      alias: "dynamicViewInjector"
    });
    this.context = input(void 0, {
      alias: "dynamicViewContext"
    });
    this.inputs = input(void 0, {
      alias: "dynamicViewInputs"
    });
    this.defaultTpl = inject(TemplateRef);
    this.vcr = inject(ViewContainerRef);
    this.viewService = inject(ViewService);
  }
  ngOnInit() {
    this.resolveContentType();
  }
  ngOnChanges(changes) {
    const viewChanged = changes.view && !changes.view.isFirstChange();
    const contextChanged = changes.context && !changes.context.isFirstChange();
    const inputsChanged = changes.inputs && !changes.inputs.isFirstChange();
    if (viewChanged) {
      this.resolveContentType();
    } else if (contextChanged) {
      this.viewRef.updateContext(this.context());
    } else if (isComponent(this.view()) && inputsChanged) {
      this.viewRef.setInputs(this.inputs() || {});
    }
  }
  resolveContentType() {
    this.viewRef?.destroy();
    const view = this.view();
    const injector = this.injector();
    const context = this.context();
    if (isString(view)) {
      const viewRef = this.viewRef = this.viewService.createComponent(DynamicViewComponent, {
        vcr: this.vcr,
        injector
      });
      viewRef.setInput("content", view).detectChanges();
    } else if (isComponent(view)) {
      this.viewRef = this.viewService.createComponent(view, {
        vcr: this.vcr,
        injector: injector ?? this.vcr.injector,
        context
      });
      const inputs = this.inputs();
      if (inputs) {
        this.viewRef.setInputs(inputs);
      }
    } else {
      this.viewRef = this.viewService.createView(view || this.defaultTpl, {
        vcr: this.vcr,
        injector: injector ?? this.vcr.injector,
        context
      });
    }
  }
  ngOnDestroy() {
    this.viewRef?.destroy();
  }
  static {
    this.ɵfac = function DynamicViewDirective_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _DynamicViewDirective)();
    };
  }
  static {
    this.ɵdir = ɵɵdefineDirective({
      type: _DynamicViewDirective,
      selectors: [["", "dynamicView", ""]],
      inputs: {
        view: [1, "dynamicView", "view"],
        injector: [1, "dynamicViewInjector", "injector"],
        context: [1, "dynamicViewContext", "context"],
        inputs: [1, "dynamicViewInputs", "inputs"]
      },
      features: [ɵɵNgOnChangesFeature]
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(DynamicViewDirective, [{
    type: Directive,
    args: [{
      selector: "[dynamicView]",
      standalone: true
    }]
  }], null, null);
})();

// node_modules/@ngxpert/hot-toast/fesm2022/ngxpert-hot-toast.mjs
var _c0 = (a0, a1) => ({
  "border-color": a0,
  "border-right-color": a1
});
function IndicatorComponent_Conditional_0_Conditional_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n  ");
    ɵɵelement(1, "hot-toast-loader", 1);
    ɵɵtext(2, "\n  ");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("theme", ctx_r0.theme);
  }
}
function IndicatorComponent_Conditional_0_Conditional_4_Case_5_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "div");
    ɵɵtext(2, "\n        ");
    ɵɵelement(3, "hot-toast-error", 1);
    ɵɵtext(4, "\n      ");
    ɵɵelementEnd();
    ɵɵtext(5, "\n      ");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(3);
    ɵɵproperty("theme", ctx_r0.theme);
  }
}
function IndicatorComponent_Conditional_0_Conditional_4_Case_6_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "div");
    ɵɵtext(2, "\n        ");
    ɵɵelement(3, "hot-toast-checkmark", 1);
    ɵɵtext(4, "\n      ");
    ɵɵelementEnd();
    ɵɵtext(5, "\n      ");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(3);
    ɵɵproperty("theme", ctx_r0.theme);
  }
}
function IndicatorComponent_Conditional_0_Conditional_4_Case_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "div");
    ɵɵtext(2, "\n        ");
    ɵɵelement(3, "hot-toast-warning", 1);
    ɵɵtext(4, "\n      ");
    ɵɵelementEnd();
    ɵɵtext(5, "\n      ");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(3);
    ɵɵproperty("theme", ctx_r0.theme);
  }
}
function IndicatorComponent_Conditional_0_Conditional_4_Case_8_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "div");
    ɵɵtext(2, "\n        ");
    ɵɵelement(3, "hot-toast-info", 1);
    ɵɵtext(4, "\n      ");
    ɵɵelementEnd();
    ɵɵtext(5, "\n      ");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext(3);
    ɵɵadvance(3);
    ɵɵproperty("theme", ctx_r0.theme);
  }
}
function IndicatorComponent_Conditional_0_Conditional_4_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n  ");
    ɵɵelementStart(1, "div", 2);
    ɵɵtext(2, "\n    ");
    ɵɵelementStart(3, "div");
    ɵɵtext(4, "\n      ");
    ɵɵtemplate(5, IndicatorComponent_Conditional_0_Conditional_4_Case_5_Template, 6, 1)(6, IndicatorComponent_Conditional_0_Conditional_4_Case_6_Template, 6, 1)(7, IndicatorComponent_Conditional_0_Conditional_4_Case_7_Template, 6, 1)(8, IndicatorComponent_Conditional_0_Conditional_4_Case_8_Template, 6, 1);
    ɵɵtext(9, "\n    ");
    ɵɵelementEnd();
    ɵɵtext(10, "\n  ");
    ɵɵelementEnd();
    ɵɵtext(11, "\n  ");
  }
  if (rf & 2) {
    let tmp_2_0;
    const ctx_r0 = ɵɵnextContext(2);
    ɵɵadvance(5);
    ɵɵconditional((tmp_2_0 = ctx_r0.type) === "error" ? 5 : tmp_2_0 === "success" ? 6 : tmp_2_0 === "warning" ? 7 : tmp_2_0 === "info" ? 8 : -1);
  }
}
function IndicatorComponent_Conditional_0_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n");
    ɵɵelementStart(1, "div", 0);
    ɵɵtext(2, "\n  ");
    ɵɵtemplate(3, IndicatorComponent_Conditional_0_Conditional_3_Template, 3, 1)(4, IndicatorComponent_Conditional_0_Conditional_4_Template, 12, 1);
    ɵɵelementEnd();
    ɵɵtext(5, "\n");
  }
  if (rf & 2) {
    const ctx_r0 = ɵɵnextContext();
    ɵɵadvance(3);
    ɵɵconditional(ctx_r0.type === "loading" ? 3 : -1);
    ɵɵadvance();
    ɵɵconditional(ctx_r0.type !== "loading" ? 4 : -1);
  }
}
function AnimatedIconComponent_ng_container_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
var _c1 = ["hotToastBarBase"];
function HotToastGroupItemComponent_Conditional_9_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n        ");
    ɵɵelementStart(1, "hot-toast-animated-icon", 7);
    ɵɵtext(2);
    ɵɵelementEnd();
    ɵɵtext(3, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("iconTheme", ctx_r1.toast.iconTheme);
    ɵɵadvance();
    ɵɵtextInterpolate(ctx_r1.toast.icon);
  }
}
function HotToastGroupItemComponent_Conditional_9_Conditional_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function HotToastGroupItemComponent_Conditional_9_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n        ");
    ɵɵelementStart(1, "div");
    ɵɵtext(2, "\n          ");
    ɵɵtemplate(3, HotToastGroupItemComponent_Conditional_9_Conditional_2_ng_container_3_Template, 1, 0, "ng-container", 8);
    ɵɵtext(4, "\n        ");
    ɵɵelementEnd();
    ɵɵtext(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance(3);
    ɵɵproperty("dynamicView", ctx_r1.toast.icon);
  }
}
function HotToastGroupItemComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, " ");
    ɵɵtemplate(1, HotToastGroupItemComponent_Conditional_9_Conditional_1_Template, 4, 2)(2, HotToastGroupItemComponent_Conditional_9_Conditional_2_Template, 6, 1);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵconditional(ctx_r1.isIconString ? 1 : 2);
  }
}
function HotToastGroupItemComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n        ");
    ɵɵelement(1, "hot-toast-indicator", 9);
    ɵɵtext(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("theme", ctx_r1.toast.iconTheme)("type", ctx_r1.toast.type);
  }
}
function HotToastGroupItemComponent_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function HotToastGroupItemComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "button", 10);
    ɵɵlistener("click", function HotToastGroupItemComponent_Conditional_17_Template_button_click_1_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.close());
    });
    ɵɵelementEnd();
    ɵɵtext(2, "\n      ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngStyle", ctx_r1.toast.closeStyle);
  }
}
var _forTrack0 = ($index, $item) => $item.id;
function HotToastComponent_Conditional_9_Conditional_1_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n        ");
    ɵɵelement(1, "hot-toast-animated-icon", 7);
    ɵɵtext(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("iconTheme", ctx_r1.toast.iconTheme)("icon", ctx_r1.toast.icon);
  }
}
function HotToastComponent_Conditional_9_Conditional_2_ng_container_3_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function HotToastComponent_Conditional_9_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n        ");
    ɵɵelementStart(1, "div");
    ɵɵtext(2, "\n          ");
    ɵɵtemplate(3, HotToastComponent_Conditional_9_Conditional_2_ng_container_3_Template, 1, 0, "ng-container", 8);
    ɵɵtext(4, "\n        ");
    ɵɵelementEnd();
    ɵɵtext(5, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance(3);
    ɵɵproperty("dynamicView", ctx_r1.toast.icon);
  }
}
function HotToastComponent_Conditional_9_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, " ");
    ɵɵtemplate(1, HotToastComponent_Conditional_9_Conditional_1_Template, 3, 2)(2, HotToastComponent_Conditional_9_Conditional_2_Template, 6, 1);
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵconditional(ctx_r1.isIconString ? 1 : 2);
  }
}
function HotToastComponent_Conditional_10_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n        ");
    ɵɵelement(1, "hot-toast-indicator", 9);
    ɵɵtext(2, "\n        ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("theme", ctx_r1.toast.iconTheme)("type", ctx_r1.toast.type);
  }
}
function HotToastComponent_ng_container_14_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵelementContainer(0);
  }
}
function HotToastComponent_Conditional_17_Template(rf, ctx) {
  if (rf & 1) {
    const _r3 = ɵɵgetCurrentView();
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "button", 10);
    ɵɵlistener("click", function HotToastComponent_Conditional_17_Template_button_click_1_listener() {
      ɵɵrestoreView(_r3);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.toggleToastGroup());
    });
    ɵɵelementEnd();
    ɵɵtext(2, "\n      ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵclassProp("expanded", ctx_r1.isExpanded);
    ɵɵproperty("ngStyle", ctx_r1.toast.group.btnStyle);
    ɵɵattribute("aria-label", ctx_r1.isExpanded ? "Collapse" : "Expand");
  }
}
function HotToastComponent_Conditional_18_Template(rf, ctx) {
  if (rf & 1) {
    const _r4 = ɵɵgetCurrentView();
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "button", 11);
    ɵɵlistener("click", function HotToastComponent_Conditional_18_Template_button_click_1_listener() {
      ɵɵrestoreView(_r4);
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.close());
    });
    ɵɵelementEnd();
    ɵɵtext(2, "\n      ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("ngStyle", ctx_r1.toast.closeStyle);
  }
}
function HotToastComponent_Conditional_20_For_4_Template(rf, ctx) {
  if (rf & 1) {
    const _r5 = ɵɵgetCurrentView();
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "hot-toast-group-item", 13);
    ɵɵlistener("height", function HotToastComponent_Conditional_20_For_4_Template_hot_toast_group_item_height_1_listener($event) {
      const item_r6 = ɵɵrestoreView(_r5).$implicit;
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.updateHeight($event, item_r6));
    })("beforeClosed", function HotToastComponent_Conditional_20_For_4_Template_hot_toast_group_item_beforeClosed_1_listener() {
      const item_r6 = ɵɵrestoreView(_r5).$implicit;
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.beforeClosedGroupItem(item_r6));
    })("afterClosed", function HotToastComponent_Conditional_20_For_4_Template_hot_toast_group_item_afterClosed_1_listener($event) {
      ɵɵrestoreView(_r5);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.afterClosedGroupItem($event));
    });
    ɵɵelementEnd();
    ɵɵtext(2, "\n      ");
  }
  if (rf & 2) {
    const item_r6 = ctx.$implicit;
    const $index_r7 = ctx.$index;
    const ctx_r1 = ɵɵnextContext(2);
    ɵɵadvance();
    ɵɵproperty("toast", item_r6)("offset", ctx_r1.calculateOffset(item_r6.id))("toastRef", ctx_r1.toastRef.groupRefs[$index_r7])("toastsAfter", (item_r6.autoClose ? ctx_r1.groupChildrenToasts.length : ctx_r1.visibleToasts.length) - 1 - $index_r7)("defaultConfig", ctx_r1.defaultConfig)("isShowingAllToasts", ctx_r1.isShowingAllToasts);
  }
}
function HotToastComponent_Conditional_20_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, "\n    ");
    ɵɵelementStart(1, "div", 12);
    ɵɵtext(2, "\n      ");
    ɵɵrepeaterCreate(3, HotToastComponent_Conditional_20_For_4_Template, 3, 6, null, null, _forTrack0);
    ɵɵelementEnd();
    ɵɵtext(5, "\n    ");
  }
  if (rf & 2) {
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵstyleProp("--hot-toast-group-height", ctx_r1.groupHeight + "px");
    ɵɵproperty("ngClass", ctx_r1.toast.group == null ? null : ctx_r1.toast.group.className);
    ɵɵadvance(2);
    ɵɵrepeater(ctx_r1.groupChildrenToasts);
  }
}
function HotToastContainerComponent_For_7_Conditional_1_Template(rf, ctx) {
}
function HotToastContainerComponent_For_7_Conditional_2_Template(rf, ctx) {
  if (rf & 1) {
    const _r1 = ɵɵgetCurrentView();
    ɵɵtext(0, "\n      ");
    ɵɵelementStart(1, "hot-toast", 2);
    ɵɵlistener("showAllToasts", function HotToastContainerComponent_For_7_Conditional_2_Template_hot_toast_showAllToasts_1_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.showAllToasts($event));
    })("height", function HotToastContainerComponent_For_7_Conditional_2_Template_hot_toast_height_1_listener($event) {
      ɵɵrestoreView(_r1);
      const toast_r3 = ɵɵnextContext().$implicit;
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.updateHeight($event, toast_r3));
    })("beforeClosed", function HotToastContainerComponent_For_7_Conditional_2_Template_hot_toast_beforeClosed_1_listener() {
      ɵɵrestoreView(_r1);
      const toast_r3 = ɵɵnextContext().$implicit;
      const ctx_r1 = ɵɵnextContext();
      return ɵɵresetView(ctx_r1.beforeClosed(toast_r3));
    })("afterClosed", function HotToastContainerComponent_For_7_Conditional_2_Template_hot_toast_afterClosed_1_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.afterClosed($event));
    })("toggleGroup", function HotToastContainerComponent_For_7_Conditional_2_Template_hot_toast_toggleGroup_1_listener($event) {
      ɵɵrestoreView(_r1);
      const ctx_r1 = ɵɵnextContext(2);
      return ɵɵresetView(ctx_r1.toggleGroup($event));
    });
    ɵɵelementEnd();
    ɵɵtext(2, "\n      ");
  }
  if (rf & 2) {
    const ctx_r3 = ɵɵnextContext();
    const toast_r3 = ctx_r3.$implicit;
    const ɵ$index_10_r5 = ctx_r3.$index;
    const ctx_r1 = ɵɵnextContext();
    ɵɵadvance();
    ɵɵproperty("toast", toast_r3)("offset", ctx_r1.calculateOffset(toast_r3.id, toast_r3.position))("toastRef", ctx_r1.toastRefs[ɵ$index_10_r5])("toastsAfter", (toast_r3.autoClose ? ctx_r1.toasts.length : ctx_r1.getVisibleToasts(toast_r3.position).length) - 1 - ɵ$index_10_r5)("defaultConfig", ctx_r1.defaultConfig)("isShowingAllToasts", ctx_r1.isShowingAllToasts);
  }
}
function HotToastContainerComponent_For_7_Template(rf, ctx) {
  if (rf & 1) {
    ɵɵtext(0, " ");
    ɵɵtemplate(1, HotToastContainerComponent_For_7_Conditional_1_Template, 0, 0)(2, HotToastContainerComponent_For_7_Conditional_2_Template, 3, 6);
  }
  if (rf & 2) {
    const toast_r3 = ctx.$implicit;
    ɵɵadvance();
    ɵɵconditional((toast_r3.group == null ? null : toast_r3.group.parent) ? 1 : 2);
  }
}
var HOT_TOAST_DEFAULT_TIMEOUTS = {
  blank: 4e3,
  error: 4e3,
  success: 4e3,
  loading: 3e4,
  warning: 4e3,
  info: 4e3
};
var EXIT_ANIMATION_DURATION = 800;
var ENTER_ANIMATION_DURATION = 350;
var HOT_TOAST_MARGIN = 8;
var HOT_TOAST_DEPTH_SCALE = 0.05;
var HOT_TOAST_DEPTH_SCALE_ADD = 1;
var HotToastRef = class {
  constructor(toast) {
    this.toast = toast;
    this.groupRefs = [];
    this.groupExpanded = false;
    this._onClosed = new Subject();
    this._onGroupToggle = new Subject();
  }
  set data(data) {
    this.toast.data = data;
  }
  get data() {
    return this.toast.data;
  }
  set dispose(value) {
    this._dispose = value;
  }
  getToast() {
    return this.toast;
  }
  /**
   * Used for internal purpose
   * Attach ToastRef to container
   */
  appendTo(container, skipAttachToParent) {
    const {
      dispose,
      updateMessage,
      updateToast,
      afterClosed,
      afterGroupToggled,
      afterGroupRefsAttached
    } = container.addToast(this, skipAttachToParent);
    this.dispose = dispose;
    this.updateMessage = updateMessage;
    this.updateToast = updateToast;
    this.afterClosed = race(this._onClosed.asObservable(), afterClosed);
    this.afterGroupToggled = race(this._onGroupToggle.asObservable(), afterGroupToggled);
    this.afterGroupRefsAttached = afterGroupRefsAttached;
    return this;
  }
  /**
   * Closes the toast
   *
   * @param [closeData={ dismissedByAction: false }] -
   * Make sure to pass { dismissedByAction: true } when closing from template
   * @memberof HotToastRef
   */
  close(closeData = {
    dismissedByAction: false
  }) {
    this.groupRefs.forEach((ref) => ref.close());
    this._dispose();
    this._onClosed.next({
      dismissedByAction: closeData.dismissedByAction,
      id: this.toast.id
    });
    this._onClosed.complete();
  }
  toggleGroup(eventData = {
    byAction: false
  }) {
    this.groupExpanded = !this.groupExpanded;
    this._onGroupToggle.next({
      byAction: eventData.byAction,
      id: this.toast.id,
      event: this.groupExpanded ? "expand" : "collapse"
    });
  }
  show() {
    this.toast.visible = true;
  }
};
var animate = (renderer, element, animation) => {
  renderer.setStyle(element, "animation", animation);
};
var LoaderComponent = class _LoaderComponent {
  static {
    this.ɵfac = function LoaderComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _LoaderComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _LoaderComponent,
      selectors: [["hot-toast-loader"]],
      inputs: {
        theme: "theme"
      },
      decls: 2,
      vars: 4,
      consts: [[1, "hot-toast-loader-icon", 3, "ngStyle"]],
      template: function LoaderComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
          ɵɵtext(1, "\n");
        }
        if (rf & 2) {
          ɵɵproperty("ngStyle", ɵɵpureFunction2(1, _c0, ctx.theme == null ? null : ctx.theme.primary, ctx.theme == null ? null : ctx.theme.secondary));
        }
      },
      dependencies: [CommonModule, NgStyle],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(LoaderComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-loader",
      changeDetection: ChangeDetectionStrategy.OnPush,
      imports: [CommonModule],
      template: `<div
  class="hot-toast-loader-icon"
  [ngStyle]="{ 'border-color': theme?.primary, 'border-right-color': theme?.secondary }"
></div>
`
    }]
  }], null, {
    theme: [{
      type: Input
    }]
  });
})();
var ErrorComponent = class _ErrorComponent {
  static {
    this.ɵfac = function ErrorComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _ErrorComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _ErrorComponent,
      selectors: [["hot-toast-error"]],
      inputs: {
        theme: "theme"
      },
      decls: 2,
      vars: 4,
      consts: [[1, "hot-toast-error-icon"]],
      template: function ErrorComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
          ɵɵtext(1, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("--error-primary", ctx.theme == null ? null : ctx.theme.primary)("--error-secondary", ctx.theme == null ? null : ctx.theme.secondary);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(ErrorComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-error",
      changeDetection: ChangeDetectionStrategy.OnPush,
      standalone: true,
      template: '<div\n  class="hot-toast-error-icon"\n  [style.--error-primary]="theme?.primary"\n  [style.--error-secondary]="theme?.secondary"\n></div>\n'
    }]
  }], null, {
    theme: [{
      type: Input
    }]
  });
})();
var CheckMarkComponent = class _CheckMarkComponent {
  static {
    this.ɵfac = function CheckMarkComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _CheckMarkComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _CheckMarkComponent,
      selectors: [["hot-toast-checkmark"]],
      inputs: {
        theme: "theme"
      },
      decls: 2,
      vars: 4,
      consts: [[1, "hot-toast-checkmark-icon"]],
      template: function CheckMarkComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
          ɵɵtext(1, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("--check-primary", ctx.theme == null ? null : ctx.theme.primary)("--check-secondary", ctx.theme == null ? null : ctx.theme.secondary);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(CheckMarkComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-checkmark",
      changeDetection: ChangeDetectionStrategy.OnPush,
      standalone: true,
      template: '<div\n  class="hot-toast-checkmark-icon"\n  [style.--check-primary]="theme?.primary"\n  [style.--check-secondary]="theme?.secondary"\n></div>\n'
    }]
  }], null, {
    theme: [{
      type: Input
    }]
  });
})();
var WarningComponent = class _WarningComponent {
  static {
    this.ɵfac = function WarningComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _WarningComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _WarningComponent,
      selectors: [["hot-toast-warning"]],
      inputs: {
        theme: "theme"
      },
      decls: 2,
      vars: 4,
      consts: [[1, "hot-toast-warning-icon"]],
      template: function WarningComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
          ɵɵtext(1, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("--warn-primary", ctx.theme == null ? null : ctx.theme.primary)("--warn-secondary", ctx.theme == null ? null : ctx.theme.secondary);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(WarningComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-warning",
      changeDetection: ChangeDetectionStrategy.OnPush,
      standalone: true,
      template: '<div\n  class="hot-toast-warning-icon"\n  [style.--warn-primary]="theme?.primary"\n  [style.--warn-secondary]="theme?.secondary"\n></div>\n'
    }]
  }], null, {
    theme: [{
      type: Input
    }]
  });
})();
var InfoComponent = class _InfoComponent {
  static {
    this.ɵfac = function InfoComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _InfoComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _InfoComponent,
      selectors: [["hot-toast-info"]],
      inputs: {
        theme: "theme"
      },
      decls: 2,
      vars: 4,
      consts: [[1, "hot-toast-info-icon"]],
      template: function InfoComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelement(0, "div", 0);
          ɵɵtext(1, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("--info-primary", ctx.theme == null ? null : ctx.theme.primary)("--info-secondary", ctx.theme == null ? null : ctx.theme.secondary);
        }
      },
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(InfoComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-info",
      changeDetection: ChangeDetectionStrategy.OnPush,
      standalone: true,
      template: '<div\n  class="hot-toast-info-icon"\n  [style.--info-primary]="theme?.primary"\n  [style.--info-secondary]="theme?.secondary"\n></div>\n'
    }]
  }], null, {
    theme: [{
      type: Input
    }]
  });
})();
var IndicatorComponent = class _IndicatorComponent {
  static {
    this.ɵfac = function IndicatorComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _IndicatorComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _IndicatorComponent,
      selectors: [["hot-toast-indicator"]],
      inputs: {
        theme: "theme",
        type: "type"
      },
      decls: 1,
      vars: 1,
      consts: [[1, "hot-toast-indicator-wrapper"], [3, "theme"], [1, "hot-toast-status-wrapper"]],
      template: function IndicatorComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵtemplate(0, IndicatorComponent_Conditional_0_Template, 6, 2);
        }
        if (rf & 2) {
          ɵɵconditional(ctx.type !== "blank" ? 0 : -1);
        }
      },
      dependencies: [LoaderComponent, ErrorComponent, CheckMarkComponent, WarningComponent, InfoComponent],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(IndicatorComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-indicator",
      changeDetection: ChangeDetectionStrategy.OnPush,
      imports: [LoaderComponent, ErrorComponent, CheckMarkComponent, WarningComponent, InfoComponent],
      template: `@if (type !== 'blank') {
<div class="hot-toast-indicator-wrapper">
  @if (type === 'loading') {
  <hot-toast-loader [theme]="theme"></hot-toast-loader>
  } @if (type !== 'loading') {
  <div class="hot-toast-status-wrapper">
    <div>
      @switch (type) { @case ('error') {
      <div>
        <hot-toast-error [theme]="theme"></hot-toast-error>
      </div>
      } @case ('success') {
      <div>
        <hot-toast-checkmark [theme]="theme"></hot-toast-checkmark>
      </div>
      } @case ('warning') {
      <div>
        <hot-toast-warning [theme]="theme"></hot-toast-warning>
      </div>
      } @case ('info') {
      <div>
        <hot-toast-info [theme]="theme"></hot-toast-info>
      </div>
      } }
    </div>
  </div>
  }
</div>
}
`
    }]
  }], null, {
    theme: [{
      type: Input
    }],
    type: [{
      type: Input
    }]
  });
})();
var AnimatedIconComponent = class _AnimatedIconComponent {
  static {
    this.ɵfac = function AnimatedIconComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _AnimatedIconComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _AnimatedIconComponent,
      selectors: [["hot-toast-animated-icon"]],
      inputs: {
        iconTheme: "iconTheme",
        icon: "icon"
      },
      decls: 5,
      vars: 3,
      consts: [[1, "hot-toast-animated-icon"], [4, "dynamicView"]],
      template: function AnimatedIconComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵtext(1, "\n  ");
          ɵɵtemplate(2, AnimatedIconComponent_ng_container_2_Template, 1, 0, "ng-container", 1);
          ɵɵtext(3, "\n");
          ɵɵelementEnd();
          ɵɵtext(4, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("color", ctx.iconTheme == null ? null : ctx.iconTheme.primary);
          ɵɵadvance(2);
          ɵɵproperty("dynamicView", ctx.icon);
        }
      },
      dependencies: [DynamicViewDirective],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(AnimatedIconComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-animated-icon",
      changeDetection: ChangeDetectionStrategy.OnPush,
      standalone: true,
      imports: [DynamicViewDirective],
      template: '<div class="hot-toast-animated-icon" [style.color]="iconTheme?.primary">\n  <ng-container *dynamicView="icon"></ng-container>\n</div>\n'
    }]
  }], null, {
    iconTheme: [{
      type: Input
    }],
    icon: [{
      type: Input
    }]
  });
})();
var HotToastGroupItemComponent = class _HotToastGroupItemComponent {
  constructor() {
    this.offset = 0;
    this._toastsAfter = 0;
    this.isShowingAllToasts = false;
    this.height = new EventEmitter();
    this.beforeClosed = new EventEmitter();
    this.afterClosed = new EventEmitter();
    this.showAllToasts = new EventEmitter();
    this.toggleGroup = new EventEmitter();
    this.isManualClose = false;
    this.toastBarBaseStylesSignal = signal({});
    this.unlisteners = [];
    this.softClosed = false;
    this.injector = inject(Injector);
    this.renderer = inject(Renderer2);
    this.ngZone = inject(NgZone);
    this.cdr = inject(ChangeDetectorRef);
  }
  set toast(value) {
    this._toast = value;
    const ogStyle = this.toastBarBaseStylesSignal();
    const newStyle = __spreadValues({}, value.style);
    if (ogStyle["animation"]?.includes("hotToastExitAnimation")) {
      newStyle["animation"] = ogStyle["animation"];
    } else {
      const top2 = value.position.includes("top");
      const enterAnimation = `hotToastEnterAnimation${top2 ? "Negative" : "Positive"} ${ENTER_ANIMATION_DURATION}ms cubic-bezier(0.21, 1.02, 0.73, 1) forwards`;
      newStyle["animation"] = enterAnimation;
    }
    this.toastBarBaseStylesSignal.set(newStyle);
  }
  get toast() {
    return this._toast;
  }
  get toastsAfter() {
    return this._toastsAfter;
  }
  set toastsAfter(value) {
    this._toastsAfter = value;
  }
  get toastBarBaseHeight() {
    return this.toastBarBase.nativeElement.offsetHeight;
  }
  get scale() {
    return this.defaultConfig.stacking !== "vertical" && !this.isShowingAllToasts ? this.toastsAfter * -HOT_TOAST_DEPTH_SCALE + 1 : 1;
  }
  get translateY() {
    return this.offset * (this.top ? 1 : -1) + "px";
  }
  get exitAnimationDelay() {
    return this.toast.duration + "ms";
  }
  get top() {
    return this.toast.position.includes("top");
  }
  get containerPositionStyle() {
    const verticalStyle = this.top ? {
      top: 0
    } : {
      bottom: 0
    };
    const transform = `translateY(var(--hot-toast-translate-y)) scale(var(--hot-toast-scale))`;
    const horizontalStyle = this.toast.position.includes("left") ? {
      left: 0
    } : this.toast.position.includes("right") ? {
      right: 0
    } : {
      left: 0,
      right: 0,
      justifyContent: "center"
    };
    return __spreadValues(__spreadValues({
      transform
    }, verticalStyle), horizontalStyle);
  }
  get isIconString() {
    return typeof this.toast.icon === "string";
  }
  get groupChildrenToastRefs() {
    return this.toastRef.groupRefs.filter((ref) => !!ref);
  }
  set groupChildrenToastRefs(value) {
    this.toastRef.groupRefs = value;
  }
  get groupChildrenToasts() {
    return this.groupChildrenToastRefs.map((ref) => ref.getToast());
  }
  get groupHeight() {
    return this.visibleToasts.map((t) => t.height).reduce((prev, curr) => prev + curr, 0);
  }
  get isExpanded() {
    return this.toastRef.groupExpanded;
  }
  ngOnChanges(changes) {
    if (changes.toast && !changes.toast.firstChange && changes.toast.currentValue?.message) {
      requestAnimationFrame(() => {
        this.height.emit(this.toastBarBase.nativeElement.offsetHeight);
      });
    }
  }
  ngOnInit() {
    if (isTemplateRef(this.toast.message)) {
      this.context = {
        $implicit: this.toastRef
      };
    }
    if (isComponent(this.toast.message)) {
      this.toastComponentInjector = Injector.create({
        providers: [{
          provide: HotToastRef,
          useValue: this.toastRef
        }],
        parent: this.toast.injector || this.injector
      });
    }
    const nativeElement = this.toastBarBase.nativeElement;
    this.ngZone.runOutsideAngular(() => {
      this.unlisteners.push(
        // Caretaker note: we have to remove these event listeners at the end (even if the element is removed from DOM).
        // zone.js stores its `ZoneTask`s within the `nativeElement[Zone.__symbol__('animationstart') + 'false']` property
        // with callback that capture `this`.
        this.renderer.listen(nativeElement, "animationstart", (event) => {
          if (this.isExitAnimation(event)) {
            this.ngZone.run(() => {
              this.renderer.setStyle(nativeElement, "pointer-events", "none");
              this.renderer.setStyle(nativeElement.parentElement, "pointer-events", "none");
              this.beforeClosed.emit();
            });
          }
        }),
        this.renderer.listen(nativeElement, "animationend", (event) => {
          if (this.isEnterAnimation(event)) {
            this.ngZone.run(() => {
              if (this.toast.autoClose) {
                const exitAnimation = `hotToastExitAnimation${this.top ? "Negative" : "Positive"} ${EXIT_ANIMATION_DURATION}ms forwards cubic-bezier(0.06, 0.71, 0.55, 1) var(--hot-toast-exit-animation-delay) var(--hot-toast-exit-animation-state)`;
                this.toastBarBaseStylesSignal.set(__spreadProps(__spreadValues({}, this.toast.style), {
                  animation: exitAnimation
                }));
              }
            });
          }
          if (this.isExitAnimation(event)) {
            this.ngZone.run(() => this.afterClosed.emit({
              dismissedByAction: this.isManualClose,
              id: this.toast.id
            }));
          }
        })
      );
    });
  }
  ngAfterViewInit() {
    const nativeElement = this.toastBarBase.nativeElement;
    requestAnimationFrame(() => {
      this.height.emit(nativeElement.offsetHeight);
    });
    this.setToastAttributes();
  }
  softClose() {
    const exitAnimation = `hotToastExitSoftAnimation${this.top ? "Negative" : "Positive"} ${EXIT_ANIMATION_DURATION}ms forwards cubic-bezier(0.06, 0.71, 0.55, 1)`;
    const nativeElement = this.toastBarBase.nativeElement;
    animate(this.renderer, nativeElement, exitAnimation);
    this.softClosed = true;
  }
  softOpen() {
    const softEnterAnimation = `hotToastEnterSoftAnimation${top ? "Negative" : "Positive"} ${ENTER_ANIMATION_DURATION}ms cubic-bezier(0.21, 1.02, 0.73, 1) forwards`;
    const nativeElement = this.toastBarBase.nativeElement;
    animate(this.renderer, nativeElement, softEnterAnimation);
    this.softClosed = false;
  }
  close() {
    this.isManualClose = true;
    this.cdr.markForCheck();
    const exitAnimation = `hotToastExitAnimation${this.top ? "Negative" : "Positive"} ${EXIT_ANIMATION_DURATION}ms forwards cubic-bezier(0.06, 0.71, 0.55, 1)`;
    this.toastBarBaseStylesSignal.set(__spreadProps(__spreadValues({}, this.toast.style), {
      animation: exitAnimation
    }));
  }
  handleMouseEnter() {
    this.showAllToasts.emit(true);
  }
  handleMouseLeave() {
    this.showAllToasts.emit(false);
  }
  ngOnDestroy() {
    this.close();
    while (this.unlisteners.length) {
      this.unlisteners.pop()();
    }
  }
  isExitAnimation(ev) {
    return ev.animationName.includes("hotToastExitAnimation");
  }
  isEnterAnimation(ev) {
    return ev.animationName.includes("hotToastEnterAnimation");
  }
  setToastAttributes() {
    const toastAttributes = this.toast.attributes;
    for (const [key, value] of Object.entries(toastAttributes)) {
      this.renderer.setAttribute(this.toastBarBase.nativeElement, key, value);
    }
  }
  get visibleToasts() {
    return this.groupChildrenToasts.filter((t) => t.visible);
  }
  static {
    this.ɵfac = function HotToastGroupItemComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _HotToastGroupItemComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _HotToastGroupItemComponent,
      selectors: [["hot-toast-group-item"]],
      viewQuery: function HotToastGroupItemComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c1, 7);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.toastBarBase = _t.first);
        }
      },
      inputs: {
        toast: "toast",
        offset: "offset",
        defaultConfig: "defaultConfig",
        toastRef: "toastRef",
        toastsAfter: "toastsAfter",
        isShowingAllToasts: "isShowingAllToasts"
      },
      outputs: {
        height: "height",
        beforeClosed: "beforeClosed",
        afterClosed: "afterClosed",
        showAllToasts: "showAllToasts",
        toggleGroup: "toggleGroup"
      },
      features: [ɵɵNgOnChangesFeature],
      decls: 21,
      vars: 21,
      consts: [["hotToastBarBase", ""], [1, "hot-toast-bar-base-container", 3, "ngStyle", "ngClass"], [1, "hot-toast-bar-base-wrapper", 3, "mouseenter", "mouseleave"], [1, "hot-toast-bar-base", 3, "ngStyle", "ngClass"], ["aria-hidden", "true", 1, "hot-toast-icon"], [1, "hot-toast-message"], [4, "dynamicView", "dynamicViewContext", "dynamicViewInjector"], [3, "iconTheme"], [4, "dynamicView"], [3, "theme", "type"], ["type", "button", "aria-label", "Close", 1, "hot-toast-close-btn", 3, "click", "ngStyle"]],
      template: function HotToastGroupItemComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 1);
          ɵɵtext(1, "\n  ");
          ɵɵelementStart(2, "div", 2);
          ɵɵlistener("mouseenter", function HotToastGroupItemComponent_Template_div_mouseenter_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.handleMouseEnter());
          })("mouseleave", function HotToastGroupItemComponent_Template_div_mouseleave_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.handleMouseLeave());
          });
          ɵɵtext(3, "\n    ");
          ɵɵelementStart(4, "div", 3, 0);
          ɵɵtext(6, "\n      ");
          ɵɵelementStart(7, "div", 4);
          ɵɵtext(8, "\n        ");
          ɵɵtemplate(9, HotToastGroupItemComponent_Conditional_9_Template, 3, 1)(10, HotToastGroupItemComponent_Conditional_10_Template, 3, 2);
          ɵɵelementEnd();
          ɵɵtext(11, "\n      ");
          ɵɵelementStart(12, "div", 5);
          ɵɵtext(13, "\n        ");
          ɵɵtemplate(14, HotToastGroupItemComponent_ng_container_14_Template, 1, 0, "ng-container", 6);
          ɵɵtext(15, "\n      ");
          ɵɵelementEnd();
          ɵɵtext(16, "\n      ");
          ɵɵtemplate(17, HotToastGroupItemComponent_Conditional_17_Template, 3, 1);
          ɵɵelementEnd();
          ɵɵtext(18, "\n  ");
          ɵɵelementEnd();
          ɵɵtext(19, "\n");
          ɵɵelementEnd();
          ɵɵtext(20, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("--hot-toast-scale", ctx.scale)("--hot-toast-translate-y", ctx.translateY);
          ɵɵproperty("ngStyle", ctx.containerPositionStyle)("ngClass", "hot-toast-theme-" + ctx.toast.theme);
          ɵɵadvance(4);
          ɵɵstyleProp("--hot-toast-animation-state", ctx.isManualClose ? "running" : "paused")("--hot-toast-exit-animation-state", ctx.isShowingAllToasts ? "paused" : "running")("--hot-toast-exit-animation-delay", ctx.exitAnimationDelay);
          ɵɵproperty("ngStyle", ctx.toastBarBaseStylesSignal())("ngClass", ctx.toast.className);
          ɵɵattribute("aria-live", ctx.toast.ariaLive)("role", ctx.toast.role);
          ɵɵadvance(5);
          ɵɵconditional(ctx.toast.icon !== void 0 ? 9 : 10);
          ɵɵadvance(5);
          ɵɵproperty("dynamicView", ctx.toast.message)("dynamicViewContext", ctx.context)("dynamicViewInjector", ctx.toastComponentInjector);
          ɵɵadvance(3);
          ɵɵconditional(ctx.toast.dismissible ? 17 : -1);
        }
      },
      dependencies: [NgClass, NgStyle, AnimatedIconComponent, IndicatorComponent, DynamicViewDirective],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HotToastGroupItemComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-group-item",
      changeDetection: ChangeDetectionStrategy.OnPush,
      imports: [NgClass, NgStyle, AnimatedIconComponent, IndicatorComponent, DynamicViewDirective],
      template: `<div
  class="hot-toast-bar-base-container"
  [ngStyle]="containerPositionStyle"
  [ngClass]="'hot-toast-theme-' + toast.theme"
  [style.--hot-toast-scale]="scale"
  [style.--hot-toast-translate-y]="translateY"
>
  <div class="hot-toast-bar-base-wrapper" (mouseenter)="handleMouseEnter()" (mouseleave)="handleMouseLeave()">
    <div
      class="hot-toast-bar-base"
      #hotToastBarBase
      [ngStyle]="toastBarBaseStylesSignal()"
      [ngClass]="toast.className"
      [style.--hot-toast-animation-state]="isManualClose ? 'running' : 'paused'"
      [style.--hot-toast-exit-animation-state]="isShowingAllToasts ? 'paused' : 'running'"
      [style.--hot-toast-exit-animation-delay]="exitAnimationDelay"
      [attr.aria-live]="toast.ariaLive"
      [attr.role]="toast.role"
    >
      <div class="hot-toast-icon" aria-hidden="true">
        @if (toast.icon !== undefined) { @if (isIconString) {
        <hot-toast-animated-icon [iconTheme]="toast.iconTheme">{{ toast.icon }}</hot-toast-animated-icon>
        } @else {
        <div>
          <ng-container *dynamicView="toast.icon"></ng-container>
        </div>
        } } @else {
        <hot-toast-indicator [theme]="toast.iconTheme" [type]="toast.type"></hot-toast-indicator>
        }
      </div>
      <div class="hot-toast-message">
        <ng-container *dynamicView="toast.message; context: context; injector: toastComponentInjector"></ng-container>
      </div>
      @if (toast.dismissible) {
      <button
        (click)="close()"
        type="button"
        class="hot-toast-close-btn"
        aria-label="Close"
        [ngStyle]="toast.closeStyle"
      ></button>
      }
    </div>
  </div>
</div>
`
    }]
  }], null, {
    toast: [{
      type: Input
    }],
    offset: [{
      type: Input
    }],
    defaultConfig: [{
      type: Input
    }],
    toastRef: [{
      type: Input
    }],
    toastsAfter: [{
      type: Input
    }],
    isShowingAllToasts: [{
      type: Input
    }],
    height: [{
      type: Output
    }],
    beforeClosed: [{
      type: Output
    }],
    afterClosed: [{
      type: Output
    }],
    showAllToasts: [{
      type: Output
    }],
    toggleGroup: [{
      type: Output
    }],
    toastBarBase: [{
      type: ViewChild,
      args: ["hotToastBarBase", {
        static: true
      }]
    }]
  });
})();
var HotToastComponent = class _HotToastComponent {
  constructor() {
    this.offset = 0;
    this._toastsAfter = 0;
    this.isShowingAllToasts = false;
    this.height = new EventEmitter();
    this.beforeClosed = new EventEmitter();
    this.afterClosed = new EventEmitter();
    this.showAllToasts = new EventEmitter();
    this.toggleGroup = new EventEmitter();
    this.isManualClose = false;
    this.isExpanded = false;
    this.toastBarBaseStylesSignal = signal({});
    this.unlisteners = [];
    this.softClosed = false;
    this.groupRefs = [];
    this.injector = inject(Injector);
    this.renderer = inject(Renderer2);
    this.ngZone = inject(NgZone);
    this.cdr = inject(ChangeDetectorRef);
  }
  set toast(value) {
    this._toast = value;
    const ogStyle = this.toastBarBaseStylesSignal();
    const newStyle = __spreadValues({}, value.style);
    if (ogStyle["animation"]?.includes("hotToastExitAnimation")) {
      newStyle["animation"] = ogStyle["animation"];
    } else {
      const top2 = value.position.includes("top");
      const enterAnimation = `hotToastEnterAnimation${top2 ? "Negative" : "Positive"} ${ENTER_ANIMATION_DURATION}ms cubic-bezier(0.21, 1.02, 0.73, 1) forwards`;
      newStyle["animation"] = enterAnimation;
    }
    this.toastBarBaseStylesSignal.set(newStyle);
  }
  get toast() {
    return this._toast;
  }
  get toastsAfter() {
    return this._toastsAfter;
  }
  set toastsAfter(value) {
    this._toastsAfter = value;
    if (this.defaultConfig?.visibleToasts > 0) {
      if (this.toast.autoClose) {
      } else {
        if (value >= this.defaultConfig?.visibleToasts) {
          this.softClose();
        } else if (this.softClosed) {
          this.softOpen();
        }
      }
    }
  }
  get toastBarBaseHeight() {
    return this.toastBarBase.nativeElement.offsetHeight;
  }
  get scale() {
    return this.defaultConfig.stacking !== "vertical" && !this.isShowingAllToasts ? this.toastsAfter * -HOT_TOAST_DEPTH_SCALE + 1 : 1;
  }
  get translateY() {
    return this.offset * (this.top ? 1 : -1) + "px";
  }
  get exitAnimationDelay() {
    return this.toast.duration + "ms";
  }
  get top() {
    return this.toast.position.includes("top");
  }
  get containerPositionStyle() {
    const verticalStyle = this.top ? {
      top: 0
    } : {
      bottom: 0
    };
    const transform = `translateY(var(--hot-toast-translate-y)) scale(var(--hot-toast-scale))`;
    const horizontalStyle = this.toast.position.includes("left") ? {
      left: 0
    } : this.toast.position.includes("right") ? {
      right: 0
    } : {
      left: 0,
      right: 0,
      justifyContent: "center"
    };
    return __spreadValues(__spreadValues({
      transform
    }, verticalStyle), horizontalStyle);
  }
  get isIconString() {
    return typeof this.toast.icon === "string";
  }
  get groupChildrenToastRefs() {
    return this.groupRefs.filter((ref) => !!ref);
  }
  set groupChildrenToastRefs(value) {
    this.groupRefs = value;
    this.toastRef.groupRefs = value;
  }
  get groupChildrenToasts() {
    return this.groupChildrenToastRefs.map((ref) => ref.getToast());
  }
  get groupHeight() {
    return this.visibleToasts.slice(-this.defaultConfig.visibleToasts).map((t) => t.height).reduce((prev, curr) => prev + curr, 0);
  }
  get visibleToasts() {
    return this.groupChildrenToasts.filter((t) => t.visible);
  }
  ngDoCheck() {
    if (this.toastRef.groupRefs.length !== this.groupRefs.length) {
      this.groupRefs = this.toastRef.groupRefs.slice();
      this.cdr.markForCheck();
      this.emiHeightWithGroup(this.isExpanded);
    }
    if (this.toastRef.groupExpanded !== this.isExpanded) {
      this.isExpanded = this.toastRef.groupExpanded;
      this.cdr.markForCheck();
      this.emiHeightWithGroup(this.isExpanded);
    }
  }
  ngOnChanges(changes) {
    if (changes.toast && !changes.toast.firstChange && changes.toast.currentValue?.message) {
      this, this.emiHeightWithGroup(this.isExpanded);
    }
  }
  ngOnInit() {
    if (isTemplateRef(this.toast.message)) {
      this.context = {
        $implicit: this.toastRef
      };
    }
    if (isComponent(this.toast.message)) {
      this.toastComponentInjector = Injector.create({
        providers: [{
          provide: HotToastRef,
          useValue: this.toastRef
        }],
        parent: this.toast.injector || this.injector
      });
    }
    const nativeElement = this.toastBarBase.nativeElement;
    this.ngZone.runOutsideAngular(() => {
      this.unlisteners.push(
        // Caretaker note: we have to remove these event listeners at the end (even if the element is removed from DOM).
        // zone.js stores its `ZoneTask`s within the `nativeElement[Zone.__symbol__('animationstart') + 'false']` property
        // with callback that capture `this`.
        this.renderer.listen(nativeElement, "animationstart", (event) => {
          if (this.isExitAnimation(event)) {
            this.ngZone.run(() => {
              this.renderer.setStyle(nativeElement, "pointer-events", "none");
              this.renderer.setStyle(nativeElement.parentElement, "pointer-events", "none");
              this.beforeClosed.emit();
            });
          }
        }),
        this.renderer.listen(nativeElement, "animationend", (event) => {
          if (this.isEnterAnimation(event)) {
            this.ngZone.run(() => {
              if (this.toast.autoClose) {
                const exitAnimation = `hotToastExitAnimation${this.top ? "Negative" : "Positive"} ${EXIT_ANIMATION_DURATION}ms forwards cubic-bezier(0.06, 0.71, 0.55, 1) var(--hot-toast-exit-animation-delay) var(--hot-toast-exit-animation-state)`;
                this.toastBarBaseStylesSignal.set(__spreadProps(__spreadValues({}, this.toast.style), {
                  animation: exitAnimation
                }));
              }
            });
          }
          if (this.isExitAnimation(event)) {
            this.ngZone.run(() => this.afterClosed.emit({
              dismissedByAction: this.isManualClose,
              id: this.toast.id
            }));
          }
        })
      );
    });
  }
  ngAfterViewInit() {
    const nativeElement = this.toastBarBase.nativeElement;
    requestAnimationFrame(() => {
      this.height.emit(nativeElement.offsetHeight);
    });
    this.setToastAttributes();
  }
  softClose() {
    const exitAnimation = `hotToastExitSoftAnimation${this.top ? "Negative" : "Positive"} ${EXIT_ANIMATION_DURATION}ms forwards cubic-bezier(0.06, 0.71, 0.55, 1)`;
    const nativeElement = this.toastBarBase.nativeElement;
    animate(this.renderer, nativeElement, exitAnimation);
    this.softClosed = true;
    if (this.isExpanded) {
      this.toggleToastGroup();
    }
  }
  softOpen() {
    const softEnterAnimation = `hotToastEnterSoftAnimation${top ? "Negative" : "Positive"} ${ENTER_ANIMATION_DURATION}ms cubic-bezier(0.21, 1.02, 0.73, 1) forwards`;
    const nativeElement = this.toastBarBase.nativeElement;
    animate(this.renderer, nativeElement, softEnterAnimation);
    this.softClosed = false;
  }
  close() {
    this.isManualClose = true;
    this.cdr.markForCheck();
    const exitAnimation = `hotToastExitAnimation${this.top ? "Negative" : "Positive"} ${EXIT_ANIMATION_DURATION}ms forwards cubic-bezier(0.06, 0.71, 0.55, 1)`;
    this.toastBarBaseStylesSignal.set(__spreadProps(__spreadValues({}, this.toast.style), {
      animation: exitAnimation
    }));
  }
  handleMouseEnter() {
    this.showAllToasts.emit(true);
  }
  handleMouseLeave() {
    this.showAllToasts.emit(false);
  }
  ngOnDestroy() {
    this.close();
    while (this.unlisteners.length) {
      this.unlisteners.pop()();
    }
  }
  isExitAnimation(ev) {
    return ev.animationName.includes("hotToastExitAnimation");
  }
  isEnterAnimation(ev) {
    return ev.animationName.includes("hotToastEnterAnimation");
  }
  setToastAttributes() {
    const toastAttributes = this.toast.attributes;
    for (const [key, value] of Object.entries(toastAttributes)) {
      this.renderer.setAttribute(this.toastBarBase.nativeElement, key, value);
    }
  }
  calculateOffset(toastId) {
    const visibleToasts = this.visibleToasts;
    const index = visibleToasts.findIndex((toast) => toast.id === toastId);
    const offset = index !== -1 ? visibleToasts.slice(...this.defaultConfig.reverseOrder ? [index + 1] : [0, index]).reduce((acc, t, i) => {
      return this.defaultConfig.visibleToasts !== 0 && i < visibleToasts.length - this.defaultConfig.visibleToasts ? 0 : acc + (t.height || 0);
    }, 0) : 0;
    return offset;
  }
  updateHeight(height, toast) {
    toast.height = height;
    this.cdr.markForCheck();
  }
  beforeClosedGroupItem(toast) {
    toast.visible = false;
    this.cdr.markForCheck();
    if (this.visibleToasts.length === 0 && this.isExpanded) {
      this.toggleToastGroup();
    } else {
      this.emiHeightWithGroup(this.isExpanded);
    }
  }
  afterClosedGroupItem(closeToast) {
    const toastIndex = this.groupChildrenToasts.findIndex((t) => t.id === closeToast.id);
    if (toastIndex > -1) {
      this.groupChildrenToastRefs = this.groupChildrenToastRefs.filter((t) => t.getToast().id !== closeToast.id);
      this.cdr.markForCheck();
    }
  }
  toggleToastGroup() {
    const event = this.isExpanded ? "collapse" : "expand";
    this.toggleGroup.emit({
      byAction: true,
      event,
      id: this.toast.id
    });
    this.emiHeightWithGroup(event === "expand");
  }
  emiHeightWithGroup(isExpanded) {
    if (isExpanded) {
      requestAnimationFrame(() => {
        this.height.emit(this.toastBarBase.nativeElement.offsetHeight + this.groupHeight);
      });
    } else {
      requestAnimationFrame(() => {
        this.height.emit(this.toastBarBase.nativeElement.offsetHeight);
      });
    }
  }
  static {
    this.ɵfac = function HotToastComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _HotToastComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _HotToastComponent,
      selectors: [["hot-toast"]],
      viewQuery: function HotToastComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(_c1, 7);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.toastBarBase = _t.first);
        }
      },
      inputs: {
        toast: "toast",
        offset: "offset",
        defaultConfig: "defaultConfig",
        toastRef: "toastRef",
        toastsAfter: "toastsAfter",
        isShowingAllToasts: "isShowingAllToasts"
      },
      outputs: {
        height: "height",
        beforeClosed: "beforeClosed",
        afterClosed: "afterClosed",
        showAllToasts: "showAllToasts",
        toggleGroup: "toggleGroup"
      },
      features: [ɵɵNgOnChangesFeature],
      decls: 23,
      vars: 25,
      consts: [["hotToastBarBase", ""], [1, "hot-toast-bar-base-container", 3, "ngStyle", "ngClass"], [1, "hot-toast-bar-base-wrapper", 3, "mouseenter", "mouseleave"], [1, "hot-toast-bar-base", 3, "ngStyle", "ngClass"], ["aria-hidden", "true", 1, "hot-toast-icon"], [1, "hot-toast-message"], [4, "dynamicView", "dynamicViewContext", "dynamicViewInjector"], [3, "iconTheme", "icon"], [4, "dynamicView"], [3, "theme", "type"], ["type", "button", 1, "hot-toast-group-btn", 3, "click", "ngStyle"], ["type", "button", "aria-label", "Close", 1, "hot-toast-close-btn", 3, "click", "ngStyle"], ["role", "list", 1, "hot-toast-bar-base-group", 3, "ngClass"], [3, "height", "beforeClosed", "afterClosed", "toast", "offset", "toastRef", "toastsAfter", "defaultConfig", "isShowingAllToasts"]],
      template: function HotToastComponent_Template(rf, ctx) {
        if (rf & 1) {
          const _r1 = ɵɵgetCurrentView();
          ɵɵelementStart(0, "div", 1);
          ɵɵtext(1, "\n  ");
          ɵɵelementStart(2, "div", 2);
          ɵɵlistener("mouseenter", function HotToastComponent_Template_div_mouseenter_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.handleMouseEnter());
          })("mouseleave", function HotToastComponent_Template_div_mouseleave_2_listener() {
            ɵɵrestoreView(_r1);
            return ɵɵresetView(ctx.handleMouseLeave());
          });
          ɵɵtext(3, "\n    ");
          ɵɵelementStart(4, "div", 3, 0);
          ɵɵtext(6, "\n      ");
          ɵɵelementStart(7, "div", 4);
          ɵɵtext(8, "\n        ");
          ɵɵtemplate(9, HotToastComponent_Conditional_9_Template, 3, 1)(10, HotToastComponent_Conditional_10_Template, 3, 2);
          ɵɵelementEnd();
          ɵɵtext(11, "\n\n      ");
          ɵɵelementStart(12, "div", 5);
          ɵɵtext(13, "\n        ");
          ɵɵtemplate(14, HotToastComponent_ng_container_14_Template, 1, 0, "ng-container", 6);
          ɵɵtext(15, "\n      ");
          ɵɵelementEnd();
          ɵɵtext(16, "\n\n      ");
          ɵɵtemplate(17, HotToastComponent_Conditional_17_Template, 3, 4)(18, HotToastComponent_Conditional_18_Template, 3, 1);
          ɵɵelementEnd();
          ɵɵtext(19, "\n\n    ");
          ɵɵtemplate(20, HotToastComponent_Conditional_20_Template, 6, 3);
          ɵɵelementEnd();
          ɵɵtext(21, "\n");
          ɵɵelementEnd();
          ɵɵtext(22, "\n");
        }
        if (rf & 2) {
          ɵɵstyleProp("--hot-toast-scale", ctx.scale)("--hot-toast-translate-y", ctx.translateY);
          ɵɵproperty("ngStyle", ctx.containerPositionStyle)("ngClass", "hot-toast-theme-" + ctx.toast.theme);
          ɵɵadvance(2);
          ɵɵclassProp("expanded", ctx.isExpanded);
          ɵɵadvance(2);
          ɵɵstyleProp("--hot-toast-animation-state", ctx.isManualClose ? "running" : "paused")("--hot-toast-exit-animation-state", ctx.isShowingAllToasts ? "paused" : "running")("--hot-toast-exit-animation-delay", ctx.exitAnimationDelay);
          ɵɵproperty("ngStyle", ctx.toastBarBaseStylesSignal())("ngClass", ctx.toast.className);
          ɵɵattribute("aria-live", ctx.toast.ariaLive)("role", ctx.toast.role);
          ɵɵadvance(5);
          ɵɵconditional(ctx.toast.icon !== void 0 ? 9 : 10);
          ɵɵadvance(5);
          ɵɵproperty("dynamicView", ctx.toast.message)("dynamicViewContext", ctx.context)("dynamicViewInjector", ctx.toastComponentInjector);
          ɵɵadvance(3);
          ɵɵconditional((ctx.toast.group == null ? null : ctx.toast.group.expandAndCollapsible) && (ctx.toast.group == null ? null : ctx.toast.group.children) && ctx.visibleToasts.length > 0 ? 17 : -1);
          ɵɵadvance();
          ɵɵconditional(ctx.toast.dismissible ? 18 : -1);
          ɵɵadvance(2);
          ɵɵconditional(ctx.toast.visible ? 20 : -1);
        }
      },
      dependencies: [CommonModule, NgClass, NgStyle, DynamicViewDirective, IndicatorComponent, AnimatedIconComponent, HotToastGroupItemComponent],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HotToastComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast",
      changeDetection: ChangeDetectionStrategy.OnPush,
      imports: [CommonModule, DynamicViewDirective, IndicatorComponent, AnimatedIconComponent, HotToastGroupItemComponent],
      template: `<div
  class="hot-toast-bar-base-container"
  [ngStyle]="containerPositionStyle"
  [ngClass]="'hot-toast-theme-' + toast.theme"
  [style.--hot-toast-scale]="scale"
  [style.--hot-toast-translate-y]="translateY"
>
  <div
    class="hot-toast-bar-base-wrapper"
    [class.expanded]="isExpanded"
    (mouseenter)="handleMouseEnter()"
    (mouseleave)="handleMouseLeave()"
  >
    <div
      class="hot-toast-bar-base"
      #hotToastBarBase
      [ngStyle]="toastBarBaseStylesSignal()"
      [ngClass]="toast.className"
      [style.--hot-toast-animation-state]="isManualClose ? 'running' : 'paused'"
      [style.--hot-toast-exit-animation-state]="isShowingAllToasts ? 'paused' : 'running'"
      [style.--hot-toast-exit-animation-delay]="exitAnimationDelay"
      [attr.aria-live]="toast.ariaLive"
      [attr.role]="toast.role"
    >
      <div class="hot-toast-icon" aria-hidden="true">
        @if (toast.icon !== undefined) { @if (isIconString) {
        <hot-toast-animated-icon [iconTheme]="toast.iconTheme" [icon]="toast.icon"></hot-toast-animated-icon>
        } @else {
        <div>
          <ng-container *dynamicView="toast.icon"></ng-container>
        </div>
        } } @else {
        <hot-toast-indicator [theme]="toast.iconTheme" [type]="toast.type"></hot-toast-indicator>
        }
      </div>

      <div class="hot-toast-message">
        <ng-container *dynamicView="toast.message; context: context; injector: toastComponentInjector"></ng-container>
      </div>

      @if (toast.group?.expandAndCollapsible && toast.group?.children && visibleToasts.length > 0) {
      <button
        (click)="toggleToastGroup()"
        type="button"
        class="hot-toast-group-btn"
        [class.expanded]="isExpanded"
        [attr.aria-label]="isExpanded ? 'Collapse' : 'Expand'"
        [ngStyle]="toast.group.btnStyle"
      ></button>
      } @if (toast.dismissible) {
      <button
        (click)="close()"
        type="button"
        class="hot-toast-close-btn"
        aria-label="Close"
        [ngStyle]="toast.closeStyle"
      ></button>
      }
    </div>

    @if (toast.visible) {
    <div
      role="list"
      class="hot-toast-bar-base-group"
      [ngClass]="toast.group?.className"
      [style.--hot-toast-group-height]="groupHeight + 'px'"
    >
      @for (item of groupChildrenToasts; track item.id) {
      <hot-toast-group-item
        [toast]="item"
        [offset]="calculateOffset(item.id)"
        [toastRef]="toastRef.groupRefs[$index]"
        [toastsAfter]="(item.autoClose ? groupChildrenToasts.length : visibleToasts.length) - 1 - $index"
        [defaultConfig]="defaultConfig"
        [isShowingAllToasts]="isShowingAllToasts"
        (height)="updateHeight($event, item)"
        (beforeClosed)="beforeClosedGroupItem(item)"
        (afterClosed)="afterClosedGroupItem($event)"
      ></hot-toast-group-item>
      }
    </div>
    }
  </div>
</div>
`
    }]
  }], null, {
    toast: [{
      type: Input
    }],
    offset: [{
      type: Input
    }],
    defaultConfig: [{
      type: Input
    }],
    toastRef: [{
      type: Input
    }],
    toastsAfter: [{
      type: Input
    }],
    isShowingAllToasts: [{
      type: Input
    }],
    height: [{
      type: Output
    }],
    beforeClosed: [{
      type: Output
    }],
    afterClosed: [{
      type: Output
    }],
    showAllToasts: [{
      type: Output
    }],
    toggleGroup: [{
      type: Output
    }],
    toastBarBase: [{
      type: ViewChild,
      args: ["hotToastBarBase", {
        static: true
      }]
    }]
  });
})();
var HotToastContainerComponent = class _HotToastContainerComponent {
  constructor() {
    this.toasts = [];
    this.toastRefs = [];
    this.isShowingAllToasts = false;
    this._onClosed = new Subject();
    this._onGroupToggle = new Subject();
    this._onGroupRefAttached = new Subject();
    this.onClosed$ = this._onClosed.asObservable();
    this.onGroupToggle$ = this._onGroupToggle.asObservable();
    this.onGroupRefAttached$ = this._onGroupRefAttached.asObservable();
    this.cdr = inject(ChangeDetectorRef);
    this.toastService = inject(HotToastService);
  }
  trackById(index, toast) {
    return toast.id;
  }
  getVisibleToasts(position) {
    return this.unGroupedToasts.filter((t) => t.visible && t.position === position);
  }
  get unGroupedToasts() {
    return this.toasts.filter((t) => t.group?.parent === void 0 || t.group?.children === void 0 || t.group?.children.length === 0);
  }
  calculateOffset(toastId, position) {
    const visibleToasts = this.getVisibleToasts(position);
    const index = visibleToasts.findIndex((toast) => toast.id === toastId);
    const offset = index !== -1 ? visibleToasts.slice(...this.defaultConfig.reverseOrder ? [index + 1] : [0, index]).reduce((acc, t, i) => {
      const toastsAfter = visibleToasts.length - 1 - i;
      return this.defaultConfig.visibleToasts !== 0 && i < visibleToasts.length - this.defaultConfig.visibleToasts ? 0 : acc + (this.defaultConfig.stacking === "vertical" || this.isShowingAllToasts ? t.height || 0 : toastsAfter * HOT_TOAST_DEPTH_SCALE + HOT_TOAST_DEPTH_SCALE_ADD) + HOT_TOAST_MARGIN;
    }, 0) : 0;
    return offset;
  }
  updateHeight(height, toast) {
    toast.height = height;
    this.cdr.markForCheck();
  }
  addToast(ref, skipAttachToParent) {
    this.toastRefs.push(ref);
    const toast = ref.getToast();
    this.toasts.push(ref.getToast());
    if (this.defaultConfig.visibleToasts !== 0 && this.unGroupedToasts.length > this.defaultConfig.visibleToasts) {
      const closeToasts = this.toasts.slice(0, this.toasts.length - this.defaultConfig.visibleToasts);
      closeToasts.forEach((t) => {
        if (t.autoClose) {
          this.closeToast(t.id);
        }
      });
    }
    this.cdr.markForCheck();
    this.attachGroupRefs(toast, ref, skipAttachToParent);
    return {
      dispose: () => {
        this.closeToast(toast.id);
      },
      updateMessage: (message) => {
        toast.message = message;
        this.updateToasts(toast);
        this.cdr.markForCheck();
      },
      updateToast: (options) => {
        this.updateToasts(toast, options);
        this.cdr.markForCheck();
      },
      afterClosed: this.getAfterClosed(toast),
      afterGroupToggled: this.getAfterGroupToggled(toast),
      afterGroupRefsAttached: this.getAfterGroupRefsAttached(toast).pipe(map((v) => v.groupRefs))
    };
  }
  attachGroupRefs(toast, ref, skipAttachToParent) {
    return __async(this, null, function* () {
      let groupRefs = [];
      if (toast.group) {
        if (toast.group.children) {
          groupRefs = yield this.createGroupRefs(toast, ref);
          const toastIndex = this.toastRefs.findIndex((t) => t.getToast().id === toast.id);
          if (toastIndex > -1) {
            this.toastRefs[toastIndex].groupRefs = groupRefs;
            this.cdr.markForCheck();
            this._onGroupRefAttached.next({
              groupRefs,
              id: toast.id
            });
          }
        } else if (toast.group.parent && !skipAttachToParent) {
          const parentToastRef = toast.group.parent;
          const parentToast = parentToastRef.getToast();
          const parentToastRefIndex = this.toastRefs.findIndex((t) => t.getToast().id === parentToast.id);
          const parentToastIndex = this.toasts.findIndex((t) => t.id === parentToast.id);
          if (parentToastRefIndex > -1 && parentToastIndex > -1) {
            this.toastRefs[parentToastRefIndex].groupRefs.push(ref);
            const existingGroup = this.toasts[parentToastRefIndex].group ?? {};
            const existingChildren = this.toasts[parentToastRefIndex].group?.children ?? [];
            existingChildren.push({
              options: __spreadProps(__spreadValues({}, toast), {
                type: toast.type,
                message: toast.message
              })
            });
            existingGroup.children = existingChildren;
            this.toasts[parentToastRefIndex].group = __spreadValues({}, existingGroup);
            this.cdr.markForCheck();
            this._onGroupRefAttached.next({
              groupRefs,
              id: parentToast.id
            });
          }
        }
      }
    });
  }
  createGroupRefs(toast, ref) {
    const skipAttachToParent = true;
    return new Promise((resolve) => {
      const items = toast.group.children;
      const allPromises = items.map((item) => {
        return new Promise((innerResolve) => {
          item.options.group = {
            parent: ref
          };
          setTimeout(() => {
            try {
              const itemRef = this.toastService.show(item.options.message, item.options, skipAttachToParent);
              innerResolve(itemRef);
            } catch (error) {
              console.error("Error creating toast", error);
              innerResolve(null);
            }
          });
        });
      });
      Promise.all(allPromises).then((refs) => resolve(refs));
    });
  }
  closeToast(id) {
    if (id) {
      const comp = this.hotToastComponentList.find((item) => item.toast.id === id);
      if (comp) {
        comp.close();
        this.cdr.markForCheck();
      }
    } else {
      this.hotToastComponentList.forEach((comp) => comp.close());
      this.cdr.markForCheck();
    }
  }
  beforeClosed(toast) {
    toast.visible = false;
    this.cdr.markForCheck();
  }
  afterClosed(closeToast) {
    const toastIndex = this.toasts.findIndex((t) => t.id === closeToast.id);
    if (toastIndex > -1) {
      this._onClosed.next(closeToast);
      this.toasts = this.toasts.filter((t) => t.id !== closeToast.id);
      this.toastRefs = this.toastRefs.filter((t) => t.getToast().id !== closeToast.id);
      this.cdr.markForCheck();
    }
  }
  toggleGroup(groupEvent) {
    const toastIndex = this.toastRefs.findIndex((t) => t.getToast().id === groupEvent.id);
    if (toastIndex > -1) {
      this._onGroupToggle.next(groupEvent);
      this.toastRefs[toastIndex].groupExpanded = groupEvent.event === "expand";
      this.cdr.markForCheck();
    }
  }
  hasToast(id) {
    return this.toasts.findIndex((t) => t.id === id) > -1;
  }
  showAllToasts(show) {
    this.isShowingAllToasts = show;
  }
  getAfterClosed(toast) {
    return this.onClosed$.pipe(filter((v) => v.id === toast.id));
  }
  getAfterGroupToggled(toast) {
    return this.onGroupToggle$.pipe(filter((v) => v.id === toast.id));
  }
  getAfterGroupRefsAttached(toast) {
    return this.onGroupRefAttached$.pipe(filter((v) => v.id === toast.id));
  }
  updateToasts(toast, options) {
    this.toasts = this.toasts.map((t) => __spreadValues(__spreadValues({}, t), t.id === toast.id && __spreadValues(__spreadValues({}, toast), options)));
    this.cdr.markForCheck();
  }
  static {
    this.ɵfac = function HotToastContainerComponent_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _HotToastContainerComponent)();
    };
  }
  static {
    this.ɵcmp = ɵɵdefineComponent({
      type: _HotToastContainerComponent,
      selectors: [["hot-toast-container"]],
      viewQuery: function HotToastContainerComponent_Query(rf, ctx) {
        if (rf & 1) {
          ɵɵviewQuery(HotToastComponent, 5);
        }
        if (rf & 2) {
          let _t;
          ɵɵqueryRefresh(_t = ɵɵloadQuery()) && (ctx.hotToastComponentList = _t);
        }
      },
      inputs: {
        defaultConfig: "defaultConfig"
      },
      decls: 11,
      vars: 0,
      consts: [[2, "position", "fixed", "z-index", "9999", "top", "0", "right", "0", "bottom", "0", "left", "0", "pointer-events", "none"], [2, "position", "relative", "height", "100%"], [3, "showAllToasts", "height", "beforeClosed", "afterClosed", "toggleGroup", "toast", "offset", "toastRef", "toastsAfter", "defaultConfig", "isShowingAllToasts"]],
      template: function HotToastContainerComponent_Template(rf, ctx) {
        if (rf & 1) {
          ɵɵelementStart(0, "div", 0);
          ɵɵtext(1, "\n  ");
          ɵɵelementStart(2, "div", 1);
          ɵɵtext(3, "\n    ");
          ɵɵelementStart(4, "div");
          ɵɵtext(5, "\n      ");
          ɵɵrepeaterCreate(6, HotToastContainerComponent_For_7_Template, 3, 1, null, null, ctx.trackById, true);
          ɵɵelementEnd();
          ɵɵtext(8, "\n  ");
          ɵɵelementEnd();
          ɵɵtext(9, "\n");
          ɵɵelementEnd();
          ɵɵtext(10, "\n");
        }
        if (rf & 2) {
          ɵɵadvance(6);
          ɵɵrepeater(ctx.toasts);
        }
      },
      dependencies: [HotToastComponent],
      encapsulation: 2,
      changeDetection: 0
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HotToastContainerComponent, [{
    type: Component,
    args: [{
      selector: "hot-toast-container",
      changeDetection: ChangeDetectionStrategy.OnPush,
      imports: [HotToastComponent],
      template: '<div style="position: fixed; z-index: 9999; top: 0; right: 0; bottom: 0; left: 0; pointer-events: none">\n  <div style="position: relative; height: 100%">\n    <div>\n      @for (toast of toasts; track trackById(i, toast); let i = $index) { @if (toast.group?.parent) {} @else {\n      <hot-toast\n        [toast]="toast"\n        [offset]="calculateOffset(toast.id, toast.position)"\n        [toastRef]="toastRefs[i]"\n        [toastsAfter]="(toast.autoClose ? toasts.length : getVisibleToasts(toast.position).length) - 1 - i"\n        [defaultConfig]="defaultConfig"\n        [isShowingAllToasts]="isShowingAllToasts"\n        (showAllToasts)="showAllToasts($event)"\n        (height)="updateHeight($event, toast)"\n        (beforeClosed)="beforeClosed(toast)"\n        (afterClosed)="afterClosed($event)"\n        (toggleGroup)="toggleGroup($event)"\n      ></hot-toast>\n      } }\n    </div>\n  </div>\n</div>\n'
    }]
  }], null, {
    defaultConfig: [{
      type: Input
    }],
    hotToastComponentList: [{
      type: ViewChildren,
      args: [HotToastComponent]
    }]
  });
})();
var ToastConfig = class {
  constructor() {
    this.reverseOrder = false;
    this.visibleToasts = 5;
    this.stacking = "vertical";
    this.ariaLive = "polite";
    this.role = "status";
    this.position = "top-center";
    this.autoClose = true;
    this.theme = "toast";
    this.attributes = {};
    this.info = {
      content: ""
    };
    this.success = {
      content: ""
    };
    this.error = {
      content: ""
    };
    this.loading = {
      content: ""
    };
    this.blank = {
      content: ""
    };
    this.warning = {
      content: ""
    };
  }
};
var isFunction = (valOrFunction) => typeof valOrFunction === "function";
var isAngularComponent = (arg) => {
  return typeof arg === "function" && arg.decorators && arg.decorators.some((decorator) => decorator.type === Component);
};
var resolveValueOrFunction = (valOrFunction, arg) => isAngularComponent(valOrFunction) ? valOrFunction : isFunction(valOrFunction) ? valOrFunction(arg) : valOrFunction;
var ToastPersistConfig = class {
  constructor() {
    this.storage = "local";
    this.key = "ngxpert/hototast-${id}";
    this.count = 1;
    this.enabled = false;
  }
};
var HotToastService = class _HotToastService {
  static {
    this.nextId = 0;
  }
  constructor() {
    this._isInitialized = false;
    this._defaultGlobalConfig = new ToastConfig();
    this._defaultPersistConfig = new ToastPersistConfig();
    this._viewService = inject(ViewService);
    this._platformId = inject(PLATFORM_ID);
    this._globalConfig = inject(ToastConfig, {
      optional: true
    });
    if (this._globalConfig) {
      this._defaultGlobalConfig = __spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._globalConfig);
    }
  }
  get defaultConfig() {
    return this._defaultGlobalConfig;
  }
  set defaultConfig(config) {
    this._defaultGlobalConfig = __spreadValues(__spreadValues({}, this._defaultGlobalConfig), config);
    if (this._componentRef) {
      this._componentRef.setInput("defaultConfig", this._defaultGlobalConfig);
    }
  }
  /**
   * Opens up an hot-toast without any pre-configurations
   *
   * @param message The message to show in the hot-toast.
   * @param [options] Additional configuration options for the hot-toast.
   * @param skipAttachToParent Only for internal usage. Setting this to true will not attach toast to it's parent.
   * @returns
   * @memberof HotToastService
   */
  show(message, options, skipAttachToParent) {
    const toast = this.createToast({
      message: message || this._defaultGlobalConfig.blank.content,
      type: options?.type ?? "blank",
      options: __spreadValues(__spreadValues({}, this._defaultGlobalConfig), options),
      skipAttachToParent
    });
    return toast;
  }
  /**
   * Opens up an hot-toast with pre-configurations for error state
   *
   * @param message The message to show in the hot-toast.
   * @param [options] Additional configuration options for the hot-toast.
   * @returns
   * @memberof HotToastService
   */
  error(message, options) {
    const toast = this.createToast({
      message: message || this._defaultGlobalConfig.error.content,
      type: "error",
      options: __spreadValues(__spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._defaultGlobalConfig?.error), options)
    });
    return toast;
  }
  /**
   * Opens up an hot-toast with pre-configurations for success state
   *
   * @param message The message to show in the hot-toast.
   * @param [options] Additional configuration options for the hot-toast.
   * @returns
   * @memberof HotToastService
   */
  success(message, options) {
    const toast = this.createToast({
      message: message || this._defaultGlobalConfig.success.content,
      type: "success",
      options: __spreadValues(__spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._defaultGlobalConfig?.success), options)
    });
    return toast;
  }
  /**
   * Opens up an hot-toast with pre-configurations for loading state
   *
   * @param message The message to show in the hot-toast.
   * @param [options] Additional configuration options for the hot-toast.
   * @returns
   * @memberof HotToastService
   */
  loading(message, options) {
    const toast = this.createToast({
      message: message || this._defaultGlobalConfig.loading.content,
      type: "loading",
      options: __spreadValues(__spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._defaultGlobalConfig?.loading), options)
    });
    return toast;
  }
  /**
   * Opens up an hot-toast with pre-configurations for warning state
   *
   * @param message The message to show in the hot-toast.
   * @param [options] Additional configuration options for the hot-toast.
   * @returns
   * @memberof HotToastService
   */
  warning(message, options) {
    const toast = this.createToast({
      message: message || this._defaultGlobalConfig.warning.content,
      type: "warning",
      options: __spreadValues(__spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._defaultGlobalConfig?.warning), options)
    });
    return toast;
  }
  /**
   * Opens up an hot-toast with pre-configurations for info state
   *
   * @param message The message to show in the hot-toast.
   * @param [options] Additional configuration options for the hot-toast.
   * @returns
   * @memberof HotToastService
   * @since 3.3.0
   */
  info(message, options) {
    const toast = this.createToast({
      message: message || this._defaultGlobalConfig.info.content,
      type: "info",
      options: __spreadValues(__spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._defaultGlobalConfig?.info), options)
    });
    return toast;
  }
  /**
   *
   *  Opens up an hot-toast with pre-configurations for loading initially and then changes state based on messages
   *
   * @template T Type of observable
   * @param messages Messages for each state i.e. loading, success and error
   * @returns
   * @memberof HotToastService
   */
  observe(messages) {
    return (source) => {
      let toastRef;
      let start = 0;
      const loadingContent = messages.loading ?? this._defaultGlobalConfig.loading?.content;
      const successContent = messages.success ?? this._defaultGlobalConfig.success?.content;
      const errorContent = messages.error ?? this._defaultGlobalConfig.error?.content;
      return defer(() => {
        if (loadingContent) {
          toastRef = this.createLoadingToast(loadingContent);
          start = Date.now();
        }
        return source.pipe(tap(__spreadValues(__spreadValues({}, successContent && {
          next: (val) => {
            toastRef = this.createOrUpdateToast(messages, val, toastRef, "success", start === 0 ? start : Date.now() - start);
          }
        }), errorContent && {
          error: (e) => {
            toastRef = this.createOrUpdateToast(messages, e, toastRef, "error", start === 0 ? start : Date.now() - start);
          }
        })));
      });
    };
  }
  /**
   * Closes the hot-toast
   *
   * @param [id] - ID of the toast
   * @since 3.0.1 - If ID is not provided, all toasts will be closed
   */
  close(id) {
    if (this._componentRef) {
      this._componentRef.ref.instance.closeToast(id);
    }
  }
  /**
   * Used for internal purpose only.
   * Creates a container component and attaches it to document.body.
   */
  init() {
    if (isPlatformServer(this._platformId)) {
      return;
    }
    this._componentRef = this._viewService.createComponent(HotToastContainerComponent).setInput("defaultConfig", this._defaultGlobalConfig).appendTo(document.body);
  }
  createOrUpdateToast(messages, val, toastRef, type, diff) {
    try {
      let content = null;
      let options = {};
      ({
        content,
        options
      } = this.getContentAndOptions(type, messages[type] || (this._defaultGlobalConfig[type] ? this._defaultGlobalConfig[type].content : "")));
      content = resolveValueOrFunction(content, val);
      if (toastRef) {
        if (options.data) {
          toastRef.data = options.data;
        }
        toastRef.updateMessage(content);
        const updatedOptions = __spreadValues(__spreadValues({
          type,
          duration: diff + HOT_TOAST_DEFAULT_TIMEOUTS[type]
        }, options), options.duration && {
          duration: diff + options.duration
        });
        toastRef.updateToast(updatedOptions);
      } else {
        this.createToast({
          message: content,
          type,
          options
        });
      }
      return toastRef;
    } catch (error) {
      console.error(error);
    }
  }
  createToast({
    message,
    type,
    options,
    observableMessages,
    skipAttachToParent
  }) {
    if (!this._isInitialized) {
      this._isInitialized = true;
      this.init();
    }
    const id = options?.id ?? `toast-${_HotToastService.nextId++}`;
    if (!this.isDuplicate(id) && (!options.persist?.enabled || options.persist?.enabled && this.handleStorageValue(id, options))) {
      const toast = __spreadValues({
        ariaLive: options?.ariaLive ?? "polite",
        createdAt: Date.now(),
        duration: options?.duration ?? HOT_TOAST_DEFAULT_TIMEOUTS[type],
        id,
        message,
        role: options?.role ?? "status",
        type,
        visible: true,
        observableMessages: observableMessages ?? void 0
      }, options);
      return new HotToastRef(toast).appendTo(this._componentRef.ref.instance, skipAttachToParent);
    }
  }
  /**
   * Checks whether any toast with same id is present.
   *
   * @private
   * @param id - Toast ID
   */
  isDuplicate(id) {
    return this._componentRef.ref.instance.hasToast(id);
  }
  /**
   * Creates an entry in local or session storage with count ${defaultConfig.persist.count}, if not present.
   * If present in storage, reduces the count
   * and returns the count.
   * Count can not be less than 0.
   */
  handleStorageValue(id, options) {
    let count = 1;
    const persist = __spreadValues(__spreadValues({}, this._defaultPersistConfig), options.persist);
    const storage = persist.storage === "local" ? localStorage : sessionStorage;
    const key = persist.key.replace(/\${id}/g, id);
    let item = storage.getItem(key);
    if (item) {
      item = parseInt(item, 10);
      if (item > 0) {
        count = item - 1;
      } else {
        count = item;
      }
    } else {
      count = persist.count;
    }
    storage.setItem(key, count.toString());
    return count;
  }
  getContentAndOptions(toastType, message) {
    var _a;
    let content;
    let options = __spreadValues(__spreadValues({}, this._defaultGlobalConfig), this._defaultGlobalConfig[toastType]);
    if (typeof message === "string" || isTemplateRef(message) || isComponent(message)) {
      content = message;
    } else {
      let restOptions;
      _a = message, {
        content
      } = _a, restOptions = __objRest(_a, [
        "content"
      ]);
      options = __spreadValues(__spreadValues({}, options), restOptions);
    }
    return {
      content,
      options
    };
  }
  createLoadingToast(messages) {
    let content = null;
    let options = {};
    ({
      content,
      options
    } = this.getContentAndOptions("loading", messages));
    return this.loading(content, options);
  }
  static {
    this.ɵfac = function HotToastService_Factory(__ngFactoryType__) {
      return new (__ngFactoryType__ || _HotToastService)();
    };
  }
  static {
    this.ɵprov = ɵɵdefineInjectable({
      token: _HotToastService,
      factory: _HotToastService.ɵfac,
      providedIn: "root"
    });
  }
};
(() => {
  (typeof ngDevMode === "undefined" || ngDevMode) && setClassMetadata(HotToastService, [{
    type: Injectable,
    args: [{
      providedIn: "root"
    }]
  }], () => [], null);
})();
function provideHotToastConfig(config) {
  return makeEnvironmentProviders([{
    provide: ToastConfig,
    useValue: config
  }]);
}
var HotToastBuilder = class {
  constructor(message, service) {
    this.message = message;
    this.service = service;
    this.options = {};
    this.groupChildren = [];
  }
  setOptions(options) {
    this.options = __spreadValues(__spreadValues({}, this.options), options);
    return this;
  }
  addChild(child) {
    this.groupChildren.push(child);
    return this;
  }
  get afterGroupRefsAttached() {
    return this.toastRef?.afterGroupRefsAttached;
  }
  addChildrenToOptions() {
    if (this.groupChildren.length > 0) {
      const children = this.groupChildren.map((child) => ({
        options: __spreadValues({
          message: child.message
        }, child.options)
      }));
      this.options.group = __spreadProps(__spreadValues({}, this.options.group), {
        children
      });
    }
  }
  // Create method that creates but doesn't show the toast. Call show() to show the toast.
  create(method = "show") {
    this.addChildrenToOptions();
    this.toastRef = this.service[method](this.message, __spreadValues(__spreadValues({}, this.options), {
      visible: false
    }));
    return this.toastRef;
  }
  createToast(method) {
    this.addChildrenToOptions();
    this.toastRef = this.service[method](this.message, this.options);
    return this.toastRef;
  }
  show() {
    return this.createToast("show");
  }
  success() {
    return this.createToast("success");
  }
  error() {
    return this.createToast("error");
  }
  warning() {
    return this.createToast("warning");
  }
  info() {
    return this.createToast("info");
  }
  loading() {
    return this.createToast("loading");
  }
};
export {
  HotToastBuilder,
  HotToastRef,
  HotToastService,
  ToastConfig,
  ToastPersistConfig,
  provideHotToastConfig,
  resolveValueOrFunction
};
//# sourceMappingURL=@ngxpert_hot-toast.js.map
